from S4Y_IOBoard.peripherals import SPI
from S4Y_IOBoard.peripherals import ChipSelect
from typing import List


def byteArrayToBitArray(byteArray: List[int]) -> List[int]:
    """Converts a list of bytes into a list of bits.

    Returns:
        List[int]: A list of bits extracted from the input bytes.
    """
    bitArray = []

    for byte in byteArray:
        for i in range(8):
            bit = (byte >> i) & 1
            bitArray.append(bit)
    return bitArray


class DigitalInputs:
    def __init__(self, spi: SPI, cs: ChipSelect) -> None:
        self.__spi = spi
        self.__cs = cs

        self.__inputCount = 40

        # SPI Settings
        self.__SPI_MODE = 0b00

    def __checkPin(self, pin: int) -> None:
        """Checks if the specified pin number is within the valid range for digital inputs.

        Raises:
            ValueError: If the pin number is out of the valid range.
        """
        if pin > self.__inputCount - 1:
            raise ValueError("Pin number exceeds maximum number of pins")

        if pin < 0:
            raise ValueError("Pin number cannot be negative")

    def __read(self) -> List[int]:
        """Performs an SPI transfer to read the state of digital inputs.

        Returns:
            List[int]: The raw byte values read from the digital input device.
        """
        self.__cs.lock.acquire()
        self.__cs.digitalInput()
        self.__spi.mode = self.__SPI_MODE

        values = self.__spi.transfer([0, 0, 0, 0, 0])
        self.__cs.lock.release()
        values = values[::-1]  # Invert the data to get the correct bit order
        return values

    @property
    def inputCount(self) -> int:
        """Retrieves the number of digital input pins available.

        Returns:
            int: The count of digital input pins.
        """
        return self.__inputCount

    def get(self, pin: int) -> int:
        """Retrieves the state of a specified digital input pin.

        Returns:
            int: The state of the digital input pin (0 or 1).

        Raises:
            ValueError: If the pin number is out of range.
        """
        self.__checkPin(pin)
        bitArray = byteArrayToBitArray(self.__read())
        return bitArray[pin]

    def getAll(self) -> List[int]:
        """Retrieves the states of all digital input pins.

        Returns:
            List[int]: A list of states for all digital input pins.
        """
        return byteArrayToBitArray(self.__read())
