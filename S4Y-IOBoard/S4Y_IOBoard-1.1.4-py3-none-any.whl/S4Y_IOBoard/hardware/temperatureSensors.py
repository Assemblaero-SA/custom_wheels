from S4Y_IOBoard.hardware import AnalogInputs
from typing import List


class TemperatureSensors:
    def __init__(self, analogInputs: AnalogInputs):
        self.__analogInputs = analogInputs
        self.__sensorCount = 4

    def __checkPin(self, pin: int) -> None:
        """Checks if the specified sensor pin number is within the valid range.

        Raises:
            ValueError: If the sensor pin number is out of range.
        """
        if pin > self.__sensorCount - 1:
            raise ValueError("Pin number exceeds maximum number of pins")

        if pin < 0:
            raise ValueError("Pin number cannot be negative")

    @property
    def sensorCount(self) -> int:
        """Gets the total number of temperature sensors available.

        Returns:
            int: The number of temperature sensors.
        """
        return self.__sensorCount

    def get(self, sensor: int) -> int:
        """Retrieves the raw ADC value for a specified temperature sensor.

        Returns:
            int: The raw ADC value from the specified temperature sensor.

        Raises:
            ValueError: If the sensor number is out of range.
        """
        self.__checkPin(sensor)

        adcValue = self.__analogInputs.get(20 + sensor)
        return adcValue

    def getAll(self) -> List[int]:
        """Retrieves the raw ADC values from all temperature sensors.

        Returns:
            List[int]: A list containing the raw ADC values for all temperature sensors.
        """
        return self.__analogInputs.getAll()[20:24]
