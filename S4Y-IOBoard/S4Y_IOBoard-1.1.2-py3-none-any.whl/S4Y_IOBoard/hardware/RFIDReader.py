from S4Y_IOBoard.peripherals.uart import UART


class RFIDReader:
    ANTENNA_1 = 1
    ANTENNA_2 = 2

    def __init__(self, uart: UART):
        self.__uart = uart

    def readTagID(self, antenna: int) -> str:
        """
        Reads the RFID tag ID using the specified antenna.

        Args:
            antenna (int): The antenna number (ANTENA_1 or ANTENA_2).

        Returns:
            str: The response from the RFID reader.

        Raises:
            ValueError: If an unknown antenna value is passed.
        """
        if antenna == self.ANTENNA_1:
            return self.__uart.transfer("s".encode("ascii"))
        elif antenna == self.ANTENNA_2:
            return self.__uart.transfer("1-s".encode("ascii"))
        else:
            raise ValueError(f"Invalid antena: {antenna}")

    def writeTagEEPROM(self, antenna: int, block: int, data: int) -> str:
        """
        Writes data to an RFID tag's EEPROM at the specified block using the specified antenna.

        Args:
            antenna (int): The antenna number (ANTENA_1 or ANTENA_2).
            block (int): The block number to write to, formatted as a two-digit hexadecimal.
            data (int): The data to write, formatted as hexadecimal.

        Returns:
            str: The response from the RFID reader.

        Raises:
            ValueError: If an unknown antenna value is passed.
        """
        hex_block = f"{block:02x}"
        hex_data = f"{data:x}"

        if antenna == self.ANTENNA_1:
            message = f"w{hex_block}{hex_data}"
        elif antenna == self.ANTENNA_2:
            message = f"1-w{hex_block}{hex_data}"
        else:
            raise ValueError(f"Invalid antena: {antenna}")

        return self.__uart.transfer(message.encode("ascii"))

    def readTagEEPROM(self, antenna: int, block: int) -> str:
        """
        Reads data from an RFID tag's EEPROM at the specified block using the specified antenna.

        Args:
            antenna (int): The antenna number (ANTENA_1 or ANTENA_2).
            block (int): The block number to read from, formatted as a two-digit hexadecimal.

        Returns:
            str: The response from the RFID reader.

        Raises:
            ValueError: If an unknown antenna value is passed.
        """
        hex_block = f"{block:02x}"

        if antenna == self.ANTENNA_1:
            message = f"r{hex_block}"
        elif antenna == self.ANTENNA_2:
            message = f"1-r{hex_block}"
        else:
            raise ValueError(f"Invalid antena: {antenna}")

        return self.__uart.transfer(message.encode("ascii"))
