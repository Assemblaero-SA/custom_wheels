from S4Y_IOBoard.peripherals import SPI
from S4Y_IOBoard.peripherals import ChipSelect
from typing import List

POWER_MODE_DEF = 3
WRITE_CTRL_DEF = True
SEQ_DEF = False
SHADOW_DEF = False
DOUT_DEF = False
RANGE_DEF = False
CODING_DEF = True


class AnalogInputs:
    def __init__(self, spi: SPI, cs: ChipSelect) -> None:
        self.__spi = spi
        self.__cs = cs

        self.__channelCount = 28
        self.__byteBuffer = [0x00, 0x00]

        self.__SPI_MODE = 0b00

        self.setPowerMode(POWER_MODE_DEF)  # set power mode to normal
        self.setDout(DOUT_DEF)  # set DOUT to three state at end of transfer
        self.setRange(RANGE_DEF)  # set range to double Vref
        self.setCoding(CODING_DEF)  # set coding to straight binary
        self.setSeq(SEQ_DEF)  # turn off sequencer
        self.setWrite(WRITE_CTRL_DEF)  # write command
        self.setShadow(SHADOW_DEF)  # turn off sequencer

    def setWrite(self, mode: bool):
        """The value written to this bit of the control register determines whether the following 11 bits are loaded to the
        control register or not."""
        self.__writec = mode

    def setSeq(self, mode: bool):
        """The SEQ bit in the control register is used in conjunction with the SHADOW bit to control the use of the sequencer
        function and access the Shadow register (see Table 12 of the datasheet)."""
        self.__seq = mode

    def setShadow(self, mode: bool):
        """The SHADOW bit in the control register is used in conjunction with the SEQ bit to control the use of the sequencer
        function and access the Shadow register (see Table 12 of the datasheet)."""
        self.__shadow = mode

    def setPowerMode(self, mode: int):
        """Power management bits. These two bits decode the mode of operation of the AD7490, as shown in Table 11."""
        if mode > 3 or mode < 0:
            raise ValueError("Power mode must be between 0 and 3")
        self.__powerMode = mode

    def setDout(self, mode: bool):
        """This bit selects the state of the DOUT line at the end of the current serial transfer. If it is set to 1, the DOUT line is
        weakly driven to the ADD3 channel address bit of the ensuing conversion. If this bit is set to 0, DOUT returns to
        three-state at the end of the serial transfer (see the Control Register section on the datashee).
        """
        self.__dout = mode

    def setRange(self, mode: bool):
        """This bit selects the analog input range to be used on the AD7490. If it is set to 0, the analog input range extends
        from 0 V to 2 × REFIN. If it is set to 1, the analog input range extends from 0 V to REFIN (see table 9 of the datasheet).
        """
        self.__range = mode

    def setCoding(self, mode: bool):
        """This bit selects the type of output coding used by the AD7490 for the conversion result. If this bit is set to 0, the
        output coding for the part is twos complement. If this bit is set to 1, the output coding from the part is straight
        binary"""
        self.__coding = mode

    @property
    def inputCount(self) -> int:
        """Return the number of analog outputs."""
        return self.__channelCount

    def begin(self) -> None:
        """Synchronizes the SPI bus, clears any misalignments from previous SPI communications.
        If the device in in sleep mode, transitions the device to a fully operational state
        """
        self.__cs.lock.acquire()
        self.__cs.analogInput_0()
        self.__spi.write([0xFF, 0xFF])
        self.__spi.write([0xFF, 0xFF])
        self.__cs.lock.release()

        self.__cs.lock.acquire()
        self.__cs.analogInput_1()
        self.__spi.write([0xFF, 0xFF])
        self.__spi.write([0xFF, 0xFF])
        self.__cs.lock.release()

    def get(self, channel: int) -> int:
        """Retrieves the ADC value of a specified channel.

        Returns:
            int: The read ADC value.

        Raises:
            ValueError: If the channel number is out of range.
        """

        self.__checkPin(channel)

        self.__cs.lock.acquire()
        if channel > 15:
            channel = channel - 16
            self.__cs.analogInput_1()
        else:
            self.__cs.analogInput_0()

        value = self.__read(channel)
        self.__cs.lock.release()

        return value

    def getAll(self) -> List[int]:
        """Retrieves ADC values from all channels.

        Returns:
            List[int]: The ADC values from all channels.
        """

        self.__cs.lock.acquire()
        self.__cs.analogInput_0()
        ic1_values = self.__readMulti(0b1111)
        self.__cs.lock.release()

        self.__cs.lock.acquire()
        self.__cs.analogInput_1()
        ic2_values = self.__readMulti(0b1011)
        self.__cs.lock.release()

        values = ic1_values + ic2_values
        return values

    def __checkPin(self, pin: int) -> None:
        """Checks if the pin number is within the valid range.

        Raises:
            ValueError: If the pin number is out of the valid range.
        """
        if pin > self.__channelCount - 1 or pin < 0:
            raise ValueError("Pin number out of range.")

    def __read(self, channel: int) -> int:
        """Performs the read operation for a given channel.

        Returns:
            int: The read ADC value.
        """
        self.__spi.mode = self.__SPI_MODE

        self.setWrite(True)
        self.__byteBuffer[0] = (
            0x00
            | (self.__writec << 7)
            | (self.__seq << 6)
            | (channel << 2)
            | (self.__powerMode)
        )
        self.__byteBuffer[1] = (
            0x00
            | (self.__shadow << 7)
            | (self.__dout << 6)
            | (self.__range << 5)
            | (self.__coding << 4)
        )

        self.__spi.write(self.__byteBuffer)
        highByte, lowByte = self.__spi.read(2)
        return (highByte & 0x0F) << 8 | lowByte

    def __readMulti(self, channels: int) -> List[int]:
        """Performs the read operation for multiple channels.

        Returns:
            List[int]: The ADC values from 0 to channels - 1.
        """

        values = []

        self.__spi.mode = self.__SPI_MODE
        self.setShadow(True)
        self.setSeq(True)
        self.setWrite(True)

        self.__byteBuffer[0] = (
            0x00
            | (self.__writec << 7)
            | (self.__seq << 6)
            | (channels << 2)
            | (self.__powerMode)
        )
        self.__byteBuffer[1] = (
            0x00
            | (self.__shadow << 7)
            | (self.__dout << 6)
            | (self.__range << 5)
            | (self.__coding << 4)
        )
        self.__spi.write(self.__byteBuffer)

        for _ in range(channels + 1):
            highByte, lowByte = self.__spi.read(2)
            values.append((highByte & 0x0F) << 8 | lowByte)

        self.setShadow(False)
        self.setSeq(False)

        return values
