from S4Y_IOBoard.peripherals import ChipSelect
from S4Y_IOBoard.hardware import AnalogInputs
from typing import List


class LoadCells:
    def __init__(self, analogInputs: AnalogInputs, cs: ChipSelect):
        self.__cs = cs
        self.__analogInputs = analogInputs
        self.__loadCellCount = 4

    def __checkPin(self, pin: int) -> None:
        """Checks if the specified pin is within the valid range for load cells.

        Raises:
            ValueError: If the pin number is out of the valid range.
        """
        if pin > self.__loadCellCount - 1 or pin < 0:
            raise ValueError("Pin number out of range.")

    @property
    def loadCellCount(self) -> int:
        """Returns the number of load cells available.

        Returns:
            int: The count of load cells.
        """
        return self.__loadCellCount

    def open(self) -> None:
        """Enable load cell comunication"""
        self.__cs.loadCellOpen()

    def close(self) -> None:
        """Disable load cell comunication"""
        self.__cs.loadCellClose()

    def get(self, cell: int) -> int:
        """Retrieves the ADC value of a specified load cell.

        Returns:
            int: The ADC value from the specified load cell.

        Raises:
            ValueError: If the cell number is out of range.
        """
        self.__checkPin(cell)

        adcValue = self.__analogInputs.get(24 + cell)
        return adcValue

    def getAll(self) -> List[int]:
        """Retrieves ADC values from all connected load cells.

        Returns:
            List[int]: ADC values from all load cells.
        """
        return self.__analogInputs.getAll()[24:]
