from S4Y_IOBoard.peripherals import SPI
from S4Y_IOBoard.peripherals import ChipSelect
from typing import List


class AnalogOutputs:
    def __init__(self, spi: SPI, cs: ChipSelect) -> None:
        self.__spi = spi
        self.__cs = cs

        self.__outputCount = 4

        # SPI Settings
        self.__SPI_MODE = 0b00

    def begin(self):
        self.reset()

    def __checkPin(self, pin: int) -> None:
        """Checks if the specified pin number is within the valid range for analog outputs.

        Raises:
            ValueError: If the pin number is out of the valid range.
        """
        if pin > self.__outputCount - 1:
            raise ValueError("Pin number exceeds maximum number of pins")

        if pin < 0:
            raise ValueError("Pin number cannot be negative")

    def __send(self, data: List[int]) -> None:
        """Sends data to the specified DAC chip over SPI."""
        self.__spi.mode = self.__SPI_MODE
        self.__spi.write(data)

    @property
    def outputCount(self) -> int:
        """Returns the number of analog output pins."""
        return self.__outputCount

    def reset(self) -> None:
        """Reset all pins to 0."""
        for pin in range(self.__outputCount):
            self.set(pin, 0)

    def set(
        self, pin: int, value: int, buffered=0x00, gain=0x01, powerDown=0x01
    ) -> None:
        """Sets the output value of an analog pin.

        Raises:
            ValueError: If the pin number is out of range.
        """
        self.__checkPin(pin)
        # odd pin numbers correspond to channel 1
        # the other ones to channel 0
        channel = pin % 2 != 0
        # the board has two analog output ICs
        # pin number greater than 1 corresponds to the second one
        self.__cs.lock.acquire()
        if pin > 1:
            self.__cs.analogOutput_1()
        else:
            self.__cs.analogOutput_0()

        config = channel << 3 | buffered << 2 | gain << 1 | powerDown

        firstByte = config << 4 | (value & 0xF00) >> 8
        secondByte = value & 0xFF

        self.__send([firstByte, secondByte])
        self.__cs.lock.release()
