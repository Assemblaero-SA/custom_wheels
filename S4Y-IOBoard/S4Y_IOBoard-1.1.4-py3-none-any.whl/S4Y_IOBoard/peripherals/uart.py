import serial
from threading import Thread, Lock


class UART:
    def __init__(self, baudrate: int, port: str):
        self.__baudrate = baudrate
        self.__port = port
        self.__readLock = Lock()
        self.__writeLock = Lock()

    def begin(self):
        self.__uart = serial.Serial(
            self.__port,
            self.__baudrate,
            parity=serial.PARITY_NONE,
            stopbits=serial.STOPBITS_ONE,
            bytesize=serial.EIGHTBITS,
            timeout=1,
        )

    @property
    def port(self) -> str:
        return self.__port

    @port.setter
    def set_port(self, port: str):
        self.__port = port

    @property
    def baudrate(self) -> int:
        return self.__baudrate

    @baudrate.setter
    def baudrate(self, baudrate: int):
        self.__baudrate = baudrate

    def write(self, data: bytes):
        self.__writeLock.acquire()
        self.__uart.write(data)
        self.__writeLock.release()

    def read(self, size: int) -> bytes:
        self.__readLock.acquire()
        data = self.__uart.read(size)
        self.__readLock.release()
        return data

    def readline(self) -> str:
        self.__readLock.acquire()
        data = self.__uart.readline().decode().strip()
        self.__readLock.release()
        return data

    def transfer(self, data: bytes) -> str:
        self.write(data)
        return self.readline()
