from smbus2 import SMBus
from typing import List, Callable
from threading import Lock


class I2CError(Exception):
    pass


class I2C:
    def __init__(self, bus: int):
        self.bus = bus
        self.__i2c = SMBus(bus)

        self.__comLock = Lock()

    @property
    def bus(self) -> int:
        """Gets the current I2C bus number.

        Returns:
            int: The I2C bus number.
        """
        return self.__bus

    @bus.setter
    def bus(self, bus: int):
        """Sets the I2C bus number to the specified value."""
        self.__bus = bus

    def __errorHandle(self, func: Callable):
        try:
            return func()
        except Exception as e:
            raise I2CError(e)

    def writeByte(self, address: int, value: int) -> None:
        """Writes a single byte to a specified I2C device address.

        Raises:
            I2CError: If the write operation fails.
        """
        self.__comLock.acquire()
        self.__errorHandle(lambda: self.__i2c.write_byte(address, value))
        self.__comLock.release()

    def writeBytes(self, address: int, values: List[int]) -> None:
        """Writes a block of bytes to a specified I2C device address.

        Raises:
            I2CError: If the write operation fails.
        """
        self.__comLock.acquire()
        self.__errorHandle(
            lambda: self.__i2c.write_i2c_block_data(address, values[0], values[1:])
        )
        self.__comLock.release()

    def readByte(self, address: int) -> int:
        """Reads a single byte from a specified I2C device address.

        Returns:
            int: The byte value read.

        Raises:
            I2CError: If the read operation fails.
        """
        self.__comLock.acquire()
        data = self.__errorHandle(lambda: self.__i2c.read_byte(address))
        self.__comLock.release()
        return data

    def readBytes(self, address: int, length: int) -> List[int]:
        """Reads a block of bytes from a specified I2C device address.

        Returns:
            List[int]: A list of byte values read.

        Raises:
            I2CError: If the read operation fails.
        """
        self.__comLock.acquire()
        data = self.__errorHandle(
            lambda: self.__i2c.read_i2c_block_data(address, 0, length)
        )
        self.__comLock.release()
        return data

    def readRegByte(self, address: int, reg: int) -> int:
        """Reads a single byte from a specified register of an I2C device.

        Returns:
            List[int]: A list of byte values read from the register.

        Raises:
            I2CError: If the read operation fails.
        """
        self.__comLock.acquire()
        data = self.__errorHandle(lambda: self.__i2c.read_byte_data(address, reg))
        self.__comLock.release()
        return data

    def readRegBytes(self, address: int, reg: int, length: int) -> List[int]:
        """Reads multiple bytes from a specified register of an I2C device.

        Returns:
            List[int]: A list of byte values read from the register.

        Raises:
            I2CError: If the read operation fails.
        """
        self.__comLock.acquire()
        data = self.__errorHandle(
            lambda: self.__i2c.read_i2c_block_data(address, reg, length)
        )
        self.__comLock.release()
        return data
