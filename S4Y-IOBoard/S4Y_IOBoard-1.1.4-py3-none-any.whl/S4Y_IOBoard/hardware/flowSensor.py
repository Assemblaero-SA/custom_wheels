import time
from S4Y_IOBoard.peripherals import I2C
from typing import List

MEDIUM_WATER = 0x08
MEDIUM_ALCOHOL = 0x15


class FlowSensor:
    def __init__(self, i2c: I2C):
        self.__i2c = i2c
        self.__address = 0x08
        self.__productNumber = 0
        self.__serialNumber = 0

    @property
    def productNumber(self) -> int:
        """Returns the product number of the sensor int hexadecimal."""
        return self.__productNumber

    @property
    def serialNumber(self) -> int:
        """Returns the serial number of the sensor int hexadecimal."""
        return self.__serialNumber

    def begin(self):
        """
        Initializes the sensor by performing a soft reset and reading the product ID and serial number.

        Raises:
            I2CError: If the write operation fails.
        """

        self.softReset()
        self.__readProductIdAndSerial()
        self.startContinuousMeasurement()

    def softReset(self) -> None:
        """
        Performs a soft reset on the sensor.

        Raises:
            I2CError: If the write operation fails.
        """

        self.__i2c.writeByte(0x00, 0x06)
        time.sleep(0.025)

    def startContinuousMeasurement(self, medium=MEDIUM_WATER) -> None:
        """
        Starts continuous measurement for the specified medium (water or alcohol).

        Parameters:
        - medium: The medium to measure (MEDIUM_WATER or MEDIUM_ALCOHOL).

        Raises:
        - ValueError if an invalid medium is specified.
        - I2CError: If the write operation fails.
        """

        if medium not in [MEDIUM_WATER, MEDIUM_ALCOHOL]:
            raise ValueError("Invalid medium specified.")

        self.__i2c.writeBytes(self.__address, [0x36, medium])
        time.sleep(0.05)

    def stopContinuousMeasurement(self) -> None:
        """
        Stops the continuous measurement process on the sensor.

        Raises:
        - I2CError: If the write operation fails.
        """

        self.__i2c.writeBytes(self.__address, [0x3F, 0xF9])

    def getFlowRate(self) -> int:
        """
        Reads the flow rate from the sensor.

        Returns:
        - The flow rate as calculated from the sensor data.

        Raises:
        - I2CError: If the read operation fails.
        """

        data = self.__readSensorData()
        flow = data[0] << 8 | data[1]
        return flow

    def getTemperature(self) -> int:
        """
        Reads the temperature from the sensor.

        Returns:
        - The temperature as calculated from the sensor data.

        Raises:
        - I2CError: If the read operation fails.
        """
        data = self.__readSensorData()
        temperature = data[3] << 8 | data[5]
        return temperature

    def __readProductIdAndSerial(self) -> None:
        """
        Read the product ID and serial number from the sensor and store them in the object.

        Raises:
        - I2CError: If the read operation fails.
        """

        command_1 = [0x36, 0x7C]
        command_2 = [0xE1, 0x02]
        self.__i2c.writeBytes(self.__address, command_1)
        self.__i2c.writeBytes(self.__address, command_2)

        data = self.__i2c.readBytes(self.__address, 18)

        productNumber = data[0] << 24 | data[1] << 16 | data[3] << 8 | data[4]
        serialNumber = (
            data[6] << 56
            | data[8] << 48
            | data[9] << 40
            | data[10] << 32
            | data[12] << 24
            | data[13] << 16
            | data[15] << 8
            | data[16]
        )
        self.__productNumber = productNumber
        self.__serialNumber = serialNumber

    def __readSensorData(self) -> List[int]:
        """
        Private method to read sensor data for flow rate and temperature measurement.

        Returns:
        - A list of bytes containing the sensor data.

        Raises:
        - I2CError: If the read operation fails.
        """

        data = self.__i2c.readBytes(self.__address, 9)
        return data
