import spidev
from typing import List
from threading import Lock


class SPI:
    def __init__(self, bus: int, device: int, maxSpeed: int, lsbFirst: bool) -> None:
        self.__spi = spidev.SpiDev()

        self.__writeLock = Lock()
        self.__readLock = Lock()

        self.maxSpeed = maxSpeed
        self.lsbFirst = lsbFirst
        self.bus = bus
        self.device = device
        self.mode = 0x00

    def __del__(self) -> None:
        """Ensures the SPI connection is closed when the object is deleted."""
        self.__spi.close()

    @property
    def maxSpeed(self) -> int:
        """Gets the maximum SPI communication speed.

        Returns:
            int: The maximum speed in Hz.
        """
        return self.__maxSpeed

    @maxSpeed.setter
    def maxSpeed(self, maxSpeed: int) -> None:
        """Sets the maximum SPI communication speed."""
        self.__maxSpeed = maxSpeed

    @property
    def lsbFirst(self) -> int:
        """Gets the bit order for SPI communication.

        Returns:
            bool: True if LSB first, False if MSB first.
        """
        return self.__lsbFirst

    @lsbFirst.setter
    def lsbFirst(self, lsbFirst: bool) -> None:
        """Sets the bit order for SPI communication."""
        self.__lsbFirst = lsbFirst

    @property
    def mode(self) -> int:
        """Gets the SPI mode.

        Returns:
            int: The current SPI mode.
        """
        return self.__mode

    @mode.setter
    def mode(self, mode: int) -> None:
        """Sets the SPI mode.

        Raises:
            ValueError: If an invalid SPI mode is provided.
        """
        if mode > 3 or mode < 0:
            raise ValueError("Invalid mode")

        self.__mode = mode

    @property
    def bus(self) -> int:
        """Gets the SPI bus number.

        Returns:
            int: The SPI bus number.
        """
        return self.__bus

    @bus.setter
    def bus(self, bus: int) -> None:
        """Gets the SPI bus number."""
        self.__bus = bus

    @property
    def device(self) -> int:
        """Gets the SPI device number.

        Returns:
            int: The SPI device number.
        """
        return self.__device

    @device.setter
    def device(self, device: int) -> None:
        """Sets the SPI device number.

        Raises:
            ValueError: If an invalid SPI device number is provided.
        """
        if device > 7 or device < 0:
            raise ValueError("Invalid device")
        self.__device = device

    def begin(self) -> None:
        """Opens the SPI connection with the previously set parameters."""
        self.__spi.open(self.__bus, self.__device)
        self.__spi.max_speed_hz = self.__maxSpeed
        self.__spi.lsbfirst = self.__lsbFirst
        self.__spi.mode = self.__mode

    def end(self) -> None:
        """Closes the SPI connection."""
        self.__spi.close()

    def write(self, data: List[int]) -> None:
        """Writes data to the SPI device."""
        self.__writeLock.acquire()
        self.__spi.writebytes(data)
        self.__writeLock.release()

    def read(self, length: int) -> List[int]:
        """Reads data from the SPI device.

        Returns:
            List[int]: The data read from the device.
        """
        self.__readLock.acquire()
        values = self.__spi.readbytes(length)
        self.__readLock.release()
        return values

    def transfer(self, data: List[int]) -> List[int]:
        """Transfers data to and from the SPI device simultaneously.

        Returns:
            List[int]: The data received from the device.
        """
        self.__writeLock.acquire()
        self.__readLock.acquire()
        values = self.__spi.xfer(data)
        self.__writeLock.release()
        self.__readLock.release()
        return values
