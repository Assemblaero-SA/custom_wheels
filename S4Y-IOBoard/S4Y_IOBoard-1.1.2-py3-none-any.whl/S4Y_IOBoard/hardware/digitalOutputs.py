from S4Y_IOBoard.peripherals import ChipSelect
from S4Y_IOBoard.peripherals import SPI
from typing import List


class DigitalOutputs:
    def __init__(self, spi: SPI, cs: ChipSelect):
        self.__spi = spi
        self.__cs = cs

        self.__outputCount = 28
        self.__pinStates = 0x00000000

        # SPI Settings
        self.__SPI_MODE = 0b11

    def begin(self):
        self.reset()

    def __send(self, data: List[int]) -> None:
        """Sends data to the digital output device over SPI.

        The method encapsulates the process of selecting the device, setting SPI mode,
        and transmitting the data.
        """
        self.__cs.lock.acquire()
        self.__cs.digitalOutput()
        self.__spi.mode = self.__SPI_MODE
        self.__spi.write(data)
        self.__cs.lock.release()

    def __checkPin(self, pin: int) -> None:
        """Checks if a given pin number is within the valid range for the device.

        Raises:
            ValueError: If the pin number is outside the valid range.
        """
        if pin > self.__outputCount - 1:
            raise ValueError("Pin number exceeds maximum number of pins")

        if pin < 0:
            raise ValueError("Pin number cannot be negative")

    @property
    def outputCount(self) -> int:
        """Gets the total number of digital output pins available on the device.

        Returns:
            int: The number of digital output pins.
        """
        return self.__outputCount

    def reset(self) -> None:
        """Resets all digital outputs to a low state (0)."""
        self.__send([0x00, 0x00, 0x00, 0x00])
        self.__pinStates = 0x00000000

    def set(self, pin: int, value: bool) -> None:
        """Sets the state of a single digital output pin.

        Raises:
            ValueError: If the pin number is outside the valid range.
        """
        self.__checkPin(pin)

        self.__pinStates &= ~(1 << pin)
        self.__pinStates |= value << pin

        byteArray = [
            (self.__pinStates >> 24) & 0xFF,
            (self.__pinStates >> 16) & 0xFF,
            (self.__pinStates >> 8) & 0xFF,
            self.__pinStates & 0xFF,
        ]

        self.__send(byteArray)

    def setMulti(self, value: int) -> None:
        """Sets the states of multiple digital outputs simultaneously using a bitmask.

        The bitmask should be a 32-bit integer where each bit represents the state
        of a pin (1 for high, 0 for low). Only the least significant 28 bits are used,
        corresponding to the available pins.
        """

        self.__pinStates = value

        byteArray = [
            (self.__pinStates >> 24) & 0xFF,
            (self.__pinStates >> 16) & 0xFF,
            (self.__pinStates >> 8) & 0xFF,
            self.__pinStates & 0xFF,
        ]

        self.__send(byteArray)
