from .hardware import DigitalOutputs
from .hardware import DigitalInputs
from .hardware import AnalogOutputs
from .hardware import AnalogInputs
from .hardware import LoadCells
from .hardware import TemperatureSensors
from .hardware import PWM
from .hardware import FlowSensor
from .hardware import RFIDReader
from .peripherals import ChipSelect
from .peripherals import I2C
from .peripherals import SPI
from .peripherals import UART

SPI_LSB_FIRST = False
SPI_BUS = 0
SPI_DEVICE = 0
SPI_SPEED = 5000000


class S4Y_IOBoard:
    def __init__(self):
        self.__i2c_1 = I2C(1)
        self.__i2c_8 = I2C(8)
        self.__spi = SPI(SPI_BUS, SPI_DEVICE, SPI_SPEED, SPI_LSB_FIRST)
        self.__spi.begin()
        self.__uart = UART(9800, "/dev/ttyTHS0")
        self.__uart.begin()
        self.__cs = ChipSelect()

        self.__digitalOutputs = DigitalOutputs(self.__spi, self.__cs)
        self.__digitalInputs = DigitalInputs(self.__spi, self.__cs)

        self.__analogOutputs = AnalogOutputs(self.__spi, self.__cs)
        self.__analogInputs = AnalogInputs(self.__spi, self.__cs)

        self.__loadCells = LoadCells(self.__analogInputs, self.__cs)
        self.__temperatureSensor = TemperatureSensors(self.__analogInputs)

        self.__pwm = PWM(self.__i2c_1)
        self.__flowSensor = FlowSensor(self.__i2c_8)

        self.__rfidReader = RFIDReader(self.__uart)

    @property
    def digitalOutputs(self) -> DigitalOutputs:
        return self.__digitalOutputs

    @property
    def digitalInputs(self) -> DigitalInputs:
        return self.__digitalInputs

    @property
    def analogOutputs(self) -> AnalogOutputs:
        return self.__analogOutputs

    @property
    def analogInputs(self) -> AnalogInputs:
        return self.__analogInputs

    @property
    def loadCells(self) -> LoadCells:
        return self.__loadCells

    @property
    def temperatureSensors(self) -> TemperatureSensors:
        return self.__temperatureSensor

    @property
    def pwm(self) -> PWM:
        return self.__pwm

    @property
    def flowSensor(self) -> FlowSensor:
        return self.__flowSensor

    @property
    def rfidReader(self) -> RFIDReader:
        return self.__rfidReader
