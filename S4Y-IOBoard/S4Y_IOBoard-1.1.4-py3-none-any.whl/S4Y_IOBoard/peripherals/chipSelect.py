import RPi.GPIO as GPIO
from multiprocessing import Lock


class ChipSelect:
    def __init__(self):
        self.__cs_A = 7
        self.__cs_B = 11
        self.__cs_C = 12
        self.__loadCellEnable = 40

        self.__lock = Lock()

        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.__cs_A, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.__cs_B, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.__cs_C, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(self.__loadCellEnable, GPIO.OUT, initial=GPIO.HIGH)

    def __del__(self):
        GPIO.cleanup()

    def digitalOutput(self):
        GPIO.output(self.__cs_A, GPIO.HIGH)
        GPIO.output(self.__cs_B, GPIO.LOW)
        GPIO.output(self.__cs_C, GPIO.LOW)

    def digitalInput(self):
        GPIO.output(self.__cs_A, GPIO.LOW)
        GPIO.output(self.__cs_B, GPIO.LOW)
        GPIO.output(self.__cs_C, GPIO.LOW)

    def analogOutput_0(self):
        GPIO.output(self.__cs_A, GPIO.LOW)
        GPIO.output(self.__cs_B, GPIO.LOW)
        GPIO.output(self.__cs_C, GPIO.HIGH)

    def analogOutput_1(self):
        GPIO.output(self.__cs_A, GPIO.HIGH)
        GPIO.output(self.__cs_B, GPIO.LOW)
        GPIO.output(self.__cs_C, GPIO.HIGH)

    def analogInput_0(self):
        GPIO.output(self.__cs_A, GPIO.LOW)
        GPIO.output(self.__cs_B, GPIO.HIGH)
        GPIO.output(self.__cs_C, GPIO.LOW)

    def analogInput_1(self):
        GPIO.output(self.__cs_A, GPIO.HIGH)
        GPIO.output(self.__cs_B, GPIO.HIGH)
        GPIO.output(self.__cs_C, GPIO.LOW)

    def loadCellOpen(self):
        GPIO.output(self.__loadCellEnable, GPIO.LOW)

    def loadCellClose(self):
        GPIO.output(self.__loadCellEnable, GPIO.HIGH)

    @property
    def lock(self):
        return self.__lock
