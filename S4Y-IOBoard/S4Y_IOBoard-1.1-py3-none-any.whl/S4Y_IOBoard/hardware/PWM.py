from S4Y_IOBoard.peripherals import I2C


class PWM:
    MODE1 = 0x00
    MODE2 = 0x01

    # Auto-Increment for all registers
    PWM_PWM = 0x82
    GRP_PWM = 0x0A
    GRP_FREQ = 0x0B

    # Output state
    OUT_BASE = 0x0C
    OUT_OFF = 0x00
    OUT_ON = 0x01
    OUT_PWM = 0x02
    OUT_GRP_PWM = 0x03

    # Error codes
    OK = 0x00
    ERROR = 0xFF
    ERR_WRITE = 0xFE
    ERR_CHAN = 0xFD
    ERR_MODE = 0xFC
    ERR_REG = 0xFB
    ERR_I2C = 0xFA

    # Configuration bits for MODE1 register
    MODE1_AUTOINCR2 = 0x80
    MODE1_AUTOINCR1 = 0x40
    MODE1_AUTOINCR0 = 0x20
    MODE1_SLEEP = 0x10
    MODE1_SUB1 = 0x08
    MODE1_SUB2 = 0x04
    MODE1_SUB3 = 0x02
    MODE1_ALLCALL = 0x01
    MODE1_NONE = 0x00

    # Configuration bits for MODE2 register
    MODE2_BLINK = 0x20
    MODE2_INVERT = 0x10
    MODE2_ACK = 0x08
    MODE2_TOTEMPOLE = 0x04
    MODE2_NONE = 0x00

    # Registers for ALLCALL and sub-addresses
    PWM_SUBAD = 0x0D
    ALLCALL_ADR = 0x11

    # Standard ALLCALL and sub-addresses
    ALLCALL = 0x70
    SUB1 = 0x71
    SUB2 = 0x72
    SUB3 = 0x74

    def __init__(self, i2c: I2C):
        self.__i2c = i2c
        self.__address = 0x01
        self.__channelCount = 5

    @property
    def channelCount(self) -> int:
        """Returns the number of PWM channels available.

        Returns:
            int: The count of PWM channels.
        """

        return self.__channelCount

    def begin(self, mode1Mask=MODE1_ALLCALL, mode2Mask=MODE2_INVERT):
        """Initializes the library after startup.
        Optionally setting the MODE1 and MODE2 configuration registers.
        See datasheet for settings possible.

        Returns:
            bool: True if initialization was successful; False otherwise.

        Raises:
            I2CError: If the write operation fails.
        """
        self.configure(mode1Mask, mode2Mask)
        self.reset()

        # Set all channels to PWM mode
        for channel in range(0, self.channelCount):
            self.setChannelMode(channel, self.OUT_PWM)

    def configure(self, mode1Mask: int, mode2Mask: int):
        """To configure the library after startup one can set the MODE1 and MODE2 configuration registers.
        See datasheet for settings possible.

        Raises:
            I2CError: If the write operation fails.
        """

        self.setMode1(mode1Mask)
        self.setMode2(mode2Mask)

    def setMode1(self, mask: int) -> None:
        """Convenience wrapper.

        Raises:
            I2CError: If the write operation fails.
        """

        self.__writeReg(self.MODE1, mask)

    def setMode2(self, mask: int) -> None:
        """Convenience wrapper.

        Raises:
            I2CError: If the write operation fails.
        """

        self.__writeReg(self.MODE2, mask)

    def setChannelMode(self, channel: int, mode: int) -> None:
        """Mode is 0..3 See datasheet for full details.

        Raises:
            I2CError: If the write operation fails.
        """

        if channel >= self.__channelCount or mode > 3:
            raise ValueError("Invalid channel or mode")
        reg = self.OUT_BASE + (channel >> 2)
        shift = (channel & self.OUT_GRP_PWM) * 2
        currentValue = self.__readReg(reg)
        newValue = (currentValue & ~(self.OUT_GRP_PWM << shift)) | (mode << shift)
        self.__writeReg(reg, newValue)

    def setBlinkGroupPwm(self, value: int) -> None:
        """Sets all channels that are part of the PWM group to value.

        Raises:
            I2CError: If the write operation fails.
        """

        self.__writeReg(self.GRP_PWM, value)

    def setBlinkGroupFreq(self, value: int) -> None:
        """Is used for blinking the group of configured LED.
        Value goes from 0 to 255 with each step representing an increase of approx.
        41 ms. So 0x00 results in 41 ms blinking period (on AND off) and 0xFF in approx.
        10.5 s.

        Raises:
            I2CError: If the write operation fails.
        """

        self.__writeReg(self.GRP_FREQ, value)

    def reset(self) -> None:
        """Resets all PWM channels to 0.

        Raises:
            I2CError: If the write operation fails.
        """
        for channel in range(self.__channelCount):
            self.set(channel, 0)

    def set(self, channel: int, value: int) -> None:
        """Sets the PWM value for the given channel. Value goes from 0 to 255.

        Raises:
            ValueError: If the channel is out of range.
            I2CError: If the write operation fails.
        """

        if channel >= self.__channelCount:
            raise ValueError("Invalid channel")
        self.__writeReg(self.OUT_PWM + channel, value)

    # Direct control
    def __writeReg(self, reg: int, value: int) -> None:
        self.__i2c.writeBytes(self.__address, [reg, value])

    def __readReg(self, reg: int) -> int:
        return self.__i2c.readRegByte(self.__address, reg)
